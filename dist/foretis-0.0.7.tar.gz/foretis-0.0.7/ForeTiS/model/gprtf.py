from . import _tensorflow_model


class Gpr(_tensorflow_model.TensorflowModel):
    """
    Implementation of a class for Gpr.

    See :obj:`~ForeTiS.model._base_model.BaseModel` for more information on the attributes.
    """
